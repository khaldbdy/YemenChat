import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { MessageCircle, LogOut, UserCircle } from "lucide-react";

const Index = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-6 bg-background px-4" dir="rtl">
      <div className="flex flex-col items-center gap-3">
        <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-primary">
          <MessageCircle className="h-11 w-11 text-primary-foreground" />
        </div>
        <h1 className="text-2xl font-bold text-foreground">YemenChat</h1>
        <p className="text-sm text-muted-foreground">
          مرحباً، {user?.user_metadata?.display_name || user?.email}
        </p>
      </div>
      <p className="max-w-xs text-center text-sm text-muted-foreground">
        تم تسجيل الدخول بنجاح! قريباً ستتمكن من بدء المحادثات.
      </p>
      <div className="flex gap-3">
        <Button onClick={() => navigate("/profile")} className="gap-2">
          <UserCircle className="h-4 w-4" />
          الملف الشخصي
        </Button>
        <Button variant="outline" onClick={signOut} className="gap-2">
          <LogOut className="h-4 w-4" />
          تسجيل الخروج
        </Button>
      </div>
    </div>
  );
};

export default Index;
