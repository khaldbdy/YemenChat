import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { ArrowRight, Camera, User, Loader2, Check } from "lucide-react";

const Profile = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [displayName, setDisplayName] = useState("");
  const [status, setStatus] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isUploading, setIsUploading] = useState(false);

  useEffect(() => {
    if (user) fetchProfile();
  }, [user]);

  const fetchProfile = async () => {
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("user_id", user!.id)
      .single();

    if (!error && data) {
      setDisplayName(data.display_name || "");
      setStatus(data.status || "");
      setPhoneNumber(data.phone_number || "");
      setAvatarUrl(data.avatar_url);
    }
    setIsLoading(false);
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    if (!file.type.startsWith("image/")) {
      toast({ variant: "destructive", title: "خطأ", description: "يرجى اختيار ملف صورة" });
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      toast({ variant: "destructive", title: "خطأ", description: "حجم الصورة يجب أن يكون أقل من 2 ميغابايت" });
      return;
    }

    setIsUploading(true);

    const fileExt = file.name.split(".").pop();
    const filePath = `${user.id}/avatar.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from("avatars")
      .upload(filePath, file, { upsert: true });

    if (uploadError) {
      toast({ variant: "destructive", title: "خطأ في رفع الصورة", description: uploadError.message });
      setIsUploading(false);
      return;
    }

    const { data: urlData } = supabase.storage.from("avatars").getPublicUrl(filePath);
    const publicUrl = `${urlData.publicUrl}?t=${Date.now()}`;

    const { error: updateError } = await supabase
      .from("profiles")
      .update({ avatar_url: publicUrl })
      .eq("user_id", user.id);

    if (updateError) {
      toast({ variant: "destructive", title: "خطأ", description: updateError.message });
    } else {
      setAvatarUrl(publicUrl);
      toast({ title: "تم التحديث", description: "تم تغيير الصورة الشخصية" });
    }

    setIsUploading(false);
  };

  const handleSave = async () => {
    if (!user) return;
    setIsSaving(true);

    const { error } = await supabase
      .from("profiles")
      .update({
        display_name: displayName.trim(),
        status: status.trim(),
        phone_number: phoneNumber.trim(),
      })
      .eq("user_id", user.id);

    if (error) {
      toast({ variant: "destructive", title: "خطأ", description: error.message });
    } else {
      toast({ title: "تم الحفظ", description: "تم تحديث الملف الشخصي بنجاح" });
    }

    setIsSaving(false);
  };

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 z-10 flex items-center gap-3 bg-primary px-4 py-3 text-primary-foreground">
        <button onClick={() => navigate("/")} className="p-1">
          <ArrowRight className="h-5 w-5" />
        </button>
        <h1 className="text-lg font-semibold">الملف الشخصي</h1>
      </div>

      {/* Avatar Section */}
      <div className="flex flex-col items-center gap-3 bg-secondary/30 py-8">
        <div className="relative">
          <div className="flex h-28 w-28 items-center justify-center overflow-hidden rounded-full bg-muted">
            {avatarUrl ? (
              <img src={avatarUrl} alt="الصورة الشخصية" className="h-full w-full object-cover" />
            ) : (
              <User className="h-14 w-14 text-muted-foreground" />
            )}
          </div>
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading}
            className="absolute bottom-0 right-0 flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-md transition-transform hover:scale-105 disabled:opacity-50"
          >
            {isUploading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Camera className="h-4 w-4" />
            )}
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleAvatarUpload}
            className="hidden"
          />
        </div>
        <p className="text-xs text-muted-foreground">اضغط على الكاميرا لتغيير الصورة</p>
      </div>

      {/* Profile Fields */}
      <div className="mx-auto max-w-lg space-y-1 p-4">
        <Card className="border-border/50">
          <CardContent className="space-y-5 pt-5">
            <div className="space-y-2">
              <Label htmlFor="displayName" className="text-xs text-primary font-medium">
                الاسم
              </Label>
              <Input
                id="displayName"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="أدخل اسمك"
                maxLength={50}
              />
              <p className="text-xs text-muted-foreground text-left" dir="ltr">
                {displayName.length}/50
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status" className="text-xs text-primary font-medium">
                الحالة
              </Label>
              <Textarea
                id="status"
                value={status}
                onChange={(e) => setStatus(e.target.value)}
                placeholder="أخبر الآخرين عنك..."
                maxLength={140}
                rows={2}
                className="resize-none"
              />
              <p className="text-xs text-muted-foreground text-left" dir="ltr">
                {status.length}/140
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone" className="text-xs text-primary font-medium">
                رقم الهاتف
              </Label>
              <Input
                id="phone"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="+967 xxx xxx xxx"
                dir="ltr"
                className="text-left"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-xs text-primary font-medium">البريد الإلكتروني</Label>
              <Input value={user?.email || ""} disabled dir="ltr" className="text-left opacity-60" />
            </div>
          </CardContent>
        </Card>

        <Button onClick={handleSave} disabled={isSaving} className="w-full gap-2 mt-4">
          {isSaving ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Check className="h-4 w-4" />
          )}
          {isSaving ? "جارٍ الحفظ..." : "حفظ التغييرات"}
        </Button>
      </div>
    </div>
  );
};

export default Profile;
